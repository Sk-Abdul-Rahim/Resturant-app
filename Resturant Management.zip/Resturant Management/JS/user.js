// var uId = localStorage.getItem('userId');
var resName
var arr = []
    // // console.log(uId)
firebase.database().ref('All Users').on('child_added', function(data) {
    resName = data.val().resturant;
    console.log(resName)
    arr.push(resName)
        // var userName = document.getElementById('name');
        // userName.innerHTML="Thank You For Login : "+resName
})
setTimeout(get = () => {
    for (let i = 0; i < arr.length; i++) {
        document.getElementById('myrest').innerHTML += `<div class="card" style="width: 18rem;">
             <img src="Images/resturant.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">${arr[i]}</h5>
                    <a href="./product.html" class="btn btn-primary">Go to Product</a>
                </div>
            </div> `
    }
}, 10000)